"use client"

import { useEffect, useState } from "react"
import Dashboard from "@/components/dashboard"
import { SidebarProvider } from "@/context/sidebar-context"
import { ContentProvider } from "@/context/content-context"

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <SidebarProvider>
      <ContentProvider>
        <Dashboard />
      </ContentProvider>
    </SidebarProvider>
  )
}
