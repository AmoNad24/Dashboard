"use client"

import { useState } from "react"
import { Search, ChevronDown } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function Topbar() {
  const [region, setRegion] = useState("India-Mumbai")

  const handleLogout = () => {
    // In a real app, this would handle logout logic
    console.log("Logging out...")
  }

  return (
    <div className="fixed top-0 left-0 w-full h-[50px] bg-[#192539] text-[#c7c5c5] border-b border-[#dee2e6] flex items-center justify-between px-0 overflow-visible z-[1001]">
      <div className="flex items-center gap-2.5 pl-2.5">
        <img src="/tcs_logo.png" alt="TCS Logo" className="h-8" />
        <div className="pl-2.5">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Search..."
              className="pl-8 py-1.5 border-none rounded bg-[#232f42] text-[#c7c5c5] border border-[#3b4656] w-[200px]"
            />
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2.5 pr-2.5 relative">
        <Select value={region} onValueChange={setRegion}>
          <SelectTrigger className="bg-[#192539] text-[#c7c5c5] border border-[#ced4da] py-1.5 px-2.5 rounded-md w-[150px]">
            <SelectValue placeholder="Select region" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="India-Mumbai">India-Mumbai</SelectItem>
            <SelectItem value="India-Hyderabad">India-Hyderabad</SelectItem>
            <SelectItem value="Australia">Australia</SelectItem>
            <SelectItem value="Japan">Japan</SelectItem>
            <SelectItem value="Singapore">Singapore</SelectItem>
          </SelectContent>
        </Select>

        <DropdownMenu>
          <DropdownMenuTrigger className="flex items-center gap-2">
            <Avatar className="h-8 w-8">
              <AvatarImage src="/avatar.png" alt="User Avatar" />
              <AvatarFallback>SK</AvatarFallback>
            </Avatar>
            <span className="max-w-[180px] overflow-hidden text-ellipsis whitespace-nowrap">Shashank Kumar</span>
            <ChevronDown className="h-4 w-4" />
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-[#192539] text-[#c7c5c5] border-0">
            <DropdownMenuItem className="cursor-pointer">Profile</DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">Settings</DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer" onClick={handleLogout}>
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )
}
