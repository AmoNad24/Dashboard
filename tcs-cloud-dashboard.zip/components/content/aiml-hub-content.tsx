import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function AiMlHubContent() {
  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
        <Card>
          <CardHeader>
            <CardTitle>Model Inventory</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li>
                <strong>Customer Churn Predictor</strong> - v1.3
                <br />
                <small className="text-gray-500">Random Forest | Accuracy: 89%</small>
              </li>
              <li>
                <strong>Image Classifier</strong> - v2.0
                <br />
                <small className="text-gray-500">ResNet-50 | Accuracy: 94%</small>
              </li>
              <li>
                <strong>Sentiment Analyzer</strong> - v1.1
                <br />
                <small className="text-gray-500">BERT | Accuracy: 91%</small>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Training Runs</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Model</TableHead>
                  <TableHead>Started</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>Churn Predictor</TableCell>
                  <TableCell>Apr 9, 2025</TableCell>
                  <TableCell>2h 15m</TableCell>
                  <TableCell className="text-[#16c784]">Completed</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Image Classifier</TableCell>
                  <TableCell>Apr 8, 2025</TableCell>
                  <TableCell>3h 22m</TableCell>
                  <TableCell className="text-[#f59e0b]">Queued</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Sentiment Analyzer</TableCell>
                  <TableCell>Apr 7, 2025</TableCell>
                  <TableCell>1h 47m</TableCell>
                  <TableCell className="text-[#ef4444]">Failed</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <Card>
          <CardHeader>
            <CardTitle>Inference Pipelines</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li>
                <strong>Real-Time Prediction:</strong> Enabled
                <br />
                <small className="text-gray-500">Latency: 120ms</small>
              </li>
              <li>
                <strong>Batch Scoring:</strong> Scheduled Daily
                <br />
                <small className="text-gray-500">Last Run: Apr 9, 2025</small>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Data Sources</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li>
                <strong>Customer Data</strong> - PostgreSQL
              </li>
              <li>
                <strong>Product Feedback</strong> - S3
              </li>
              <li>
                <strong>Social Feeds</strong> - Kafka
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
