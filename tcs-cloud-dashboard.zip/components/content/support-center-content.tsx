"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"

export default function SupportCenterContent() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Support Center</h2>
      <p className="text-gray-600 mb-6">
        Access help resources, manage support tickets, and engage with automated or human support for fast issue
        resolution.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Open Tickets</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">14</div>
            <div className="text-sm text-gray-500">Across all departments</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Resolved This Month</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">89</div>
            <div className="text-sm text-gray-500">March 2025</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Knowledge Base Articles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">152</div>
            <div className="text-sm text-gray-500">Available for reference</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Live Agents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">6</div>
            <div className="text-sm text-gray-500">Currently Online</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
        <Card>
          <CardHeader>
            <CardTitle>Recent Tickets</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>#10234</TableCell>
                  <TableCell>Database latency issue</TableCell>
                  <TableCell className="text-[#ef4444]">High</TableCell>
                  <TableCell className="text-[#f59e0b]">In Progress</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>#10212</TableCell>
                  <TableCell>VPN connection failed</TableCell>
                  <TableCell className="text-[#f59e0b]">Medium</TableCell>
                  <TableCell className="text-[#16c784]">Resolved</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>#10199</TableCell>
                  <TableCell>Unable to launch instance</TableCell>
                  <TableCell className="text-[#facc15]">Low</TableCell>
                  <TableCell className="text-[#16c784]">Resolved</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>#10187</TableCell>
                  <TableCell>UI glitch on metrics page</TableCell>
                  <TableCell className="text-[#facc15]">Low</TableCell>
                  <TableCell className="text-[#f59e0b]">Investigating</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Knowledge Base Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li>
                <strong>Compute:</strong> VM provisioning, scaling, and rebooting
              </li>
              <li>
                <strong>Networking:</strong> Firewall setup, VPN issues, DNS
              </li>
              <li>
                <strong>Billing:</strong> Invoice management, credit usage
              </li>
              <li>
                <strong>Storage:</strong> Backup, snapshot, replication guides
              </li>
              <li>
                <strong>Access Control:</strong> MFA, RBAC, and SSO setup
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-5">
        <Card>
          <CardHeader>
            <CardTitle>AI Chatbot Support</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              Our AI assistant is available 24/7 to help you troubleshoot common issues or direct you to helpful
              resources.
            </p>
            <ul className="space-y-2 mb-4">
              <li>
                <strong>Chatbot Status:</strong> Online
              </li>
              <li>
                <strong>Average Resolution Time:</strong> 1.2 mins
              </li>
              <li>
                <strong>Escalation Rate:</strong> 12%
              </li>
            </ul>
            <Button onClick={() => alert("Launching Chatbot...")}>Chat Now</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
