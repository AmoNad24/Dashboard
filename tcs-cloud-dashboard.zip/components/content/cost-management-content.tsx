"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Chart } from "@/components/ui/chart"

export default function CostManagementContent() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Cost Management</h2>
      <p className="text-gray-600 mb-6">
        Monitor cloud spend, optimize resource allocation, and track budgeting goals across departments.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Spend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$128,400</div>
            <div className="text-sm text-gray-500">Month-to-date</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Forecasted Spend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$142,000</div>
            <div className="text-sm text-gray-500">For April 2025</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Budget Utilization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">86%</div>
            <div className="text-sm text-gray-500">Monthly Budget: $165,000</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
        <Card>
          <CardHeader>
            <CardTitle>Region-wise Cost Split</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="regionCostChart"
                type="doughnut"
                data={{
                  labels: ["India-Mumbai", "India-Hyderabad", "Australia", "Japan", "Singapore"],
                  datasets: [
                    {
                      data: [34000, 27000, 21000, 16000, 14000],
                      backgroundColor: ["#3b82f6", "#10b981", "#f59e0b", "#6366f1", "#ef4444"],
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: "bottom",
                    },
                  },
                }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Resource-type Cost Split</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="resourceCostChart"
                type="bar"
                data={{
                  labels: ["Compute", "Storage", "Database", "Networking", "Monitoring"],
                  datasets: [
                    {
                      label: "Cost ($)",
                      data: [48000, 32000, 24000, 15000, 9000],
                      backgroundColor: "#60a5fa",
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { display: false },
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      ticks: {
                        callback: (value: any) => `$${value}`,
                      },
                    },
                  },
                }}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-5">
        <Card>
          <CardHeader>
            <CardTitle>Pricing Details</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Service</TableHead>
                  <TableHead>Unit Price</TableHead>
                  <TableHead>Usage</TableHead>
                  <TableHead>Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>Compute (VM)</TableCell>
                  <TableCell>$0.12/hr</TableCell>
                  <TableCell>25,000 hrs</TableCell>
                  <TableCell>$3,000</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Storage (Block)</TableCell>
                  <TableCell>$0.10/GB</TableCell>
                  <TableCell>5,000 GB</TableCell>
                  <TableCell>$500</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Object Storage</TableCell>
                  <TableCell>$0.023/GB</TableCell>
                  <TableCell>12,000 GB</TableCell>
                  <TableCell>$276</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Data Transfer</TableCell>
                  <TableCell>$0.09/GB</TableCell>
                  <TableCell>8,000 GB</TableCell>
                  <TableCell>$720</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Database Services</TableCell>
                  <TableCell>$0.25/hr</TableCell>
                  <TableCell>3,000 hrs</TableCell>
                  <TableCell>$750</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
