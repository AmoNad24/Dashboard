"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Chart } from "@/components/ui/chart"

export default function ObservabilityContent() {
  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <div className="text-sm text-gray-500">Across all regions</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Log Events (24h)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5.2M</div>
            <div className="text-sm text-gray-500">Processed logs</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Average Latency</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">123 ms</div>
            <div className="text-sm text-gray-500">Across services</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">System Uptime</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">99.97%</div>
            <div className="text-sm text-gray-500">Last 30 days</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-5">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Recent Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Time</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Severity</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>2025-04-15 11:42</TableCell>
                  <TableCell>Auth</TableCell>
                  <TableCell className="text-[#ef4444]">Critical</TableCell>
                  <TableCell className="text-[#f59e0b]">Investigating</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-15 10:15</TableCell>
                  <TableCell>Compute</TableCell>
                  <TableCell className="text-[#facc15]">Warning</TableCell>
                  <TableCell className="text-[#16c784]">Resolved</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-15 09:30</TableCell>
                  <TableCell>Storage</TableCell>
                  <TableCell className="text-[#ef4444]">Critical</TableCell>
                  <TableCell className="text-[#ef4444]">Unresolved</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Top Noisy Services</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Service</TableHead>
                  <TableHead>Alerts (Last 7 Days)</TableHead>
                  <TableHead>Avg. Severity</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>Compute</TableCell>
                  <TableCell>42</TableCell>
                  <TableCell className="text-[#f59e0b]">Warning</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Storage</TableCell>
                  <TableCell>35</TableCell>
                  <TableCell className="text-[#ef4444]">Critical</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Network</TableCell>
                  <TableCell>28</TableCell>
                  <TableCell className="text-[#facc15]">Moderate</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Uptime Summary (Last 7 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Service</TableHead>
                  <TableHead>Uptime %</TableHead>
                  <TableHead>Outages</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>Compute</TableCell>
                  <TableCell>99.95%</TableCell>
                  <TableCell>2</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Storage</TableCell>
                  <TableCell>99.91%</TableCell>
                  <TableCell>3</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Network</TableCell>
                  <TableCell>99.98%</TableCell>
                  <TableCell>1</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <Card>
          <CardHeader>
            <CardTitle>Alert Volume (Last 7 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px]">
              <Chart
                id="observabilityAlertChart"
                type="line"
                data={{
                  labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
                  datasets: [
                    {
                      label: "Alerts",
                      data: [12, 15, 10, 8, 9, 14, 11],
                      borderColor: "#ef4444",
                      backgroundColor: "rgba(239,68,68,0.2)",
                      fill: true,
                      tension: 0.4,
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Latency by Service</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px]">
              <Chart
                id="observabilityLatencyChart"
                type="bar"
                data={{
                  labels: ["Auth", "Storage", "Compute", "Network", "Billing"],
                  datasets: [
                    {
                      label: "Latency (ms)",
                      data: [110, 98, 140, 120, 95],
                      backgroundColor: "#3b82f6",
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                  scales: {
                    y: {
                      beginAtZero: true,
                      ticks: {
                        callback: (value: any) => `${value} ms`,
                      },
                    },
                  },
                }}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
