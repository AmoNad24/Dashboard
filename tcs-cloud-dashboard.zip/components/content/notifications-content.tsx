"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Chart } from "@/components/ui/chart"

export default function NotificationsContent() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Notifications</h2>
      <p className="text-gray-600 mb-6">
        Stay informed with system alerts, incident reports, audit events, and system-wide announcements.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">320</div>
            <div className="text-sm text-gray-500">Across all systems</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Incidents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">7</div>
            <div className="text-sm text-gray-500">Under investigation</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Audit Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,120</div>
            <div className="text-sm text-gray-500">Last 7 days</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Broadcasts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <div className="text-sm text-gray-500">Posted this month</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
        <Card>
          <CardHeader>
            <CardTitle>Alert Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="alertDistributionChart"
                type="doughnut"
                data={{
                  labels: ["Critical", "Warning", "Info"],
                  datasets: [
                    {
                      data: [32, 74, 214],
                      backgroundColor: ["#ef4444", "#f59e0b", "#60a5fa"],
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: "bottom",
                    },
                  },
                }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Broadcasts</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li>
                <strong>April 9:</strong> Patch rollout for east region at 2:00 AM
              </li>
              <li>
                <strong>April 7:</strong> High CPU usage alert rule updated
              </li>
              <li>
                <strong>April 5:</strong> New audit retention policy applied
              </li>
              <li>
                <strong>April 3:</strong> Certificate renewal scheduled
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-5">
        <Card>
          <CardHeader>
            <CardTitle>Incident Timeline</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Time</TableHead>
                  <TableHead>Severity</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>2025-04-09 08:45</TableCell>
                  <TableCell className="text-[#ef4444]">Critical</TableCell>
                  <TableCell>App outage in US-East</TableCell>
                  <TableCell className="text-[#f59e0b]">Investigating</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-08 14:30</TableCell>
                  <TableCell className="text-[#facc15]">Warning</TableCell>
                  <TableCell>High memory usage in node group-2</TableCell>
                  <TableCell className="text-[#16c784]">Resolved</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-07 10:10</TableCell>
                  <TableCell className="text-[#facc15]">Warning</TableCell>
                  <TableCell>Unusual login activity detected</TableCell>
                  <TableCell className="text-[#f59e0b]">Investigating</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-06 09:15</TableCell>
                  <TableCell className="text-[#16c784]">Info</TableCell>
                  <TableCell>Backup completed successfully</TableCell>
                  <TableCell className="text-[#16c784]">Resolved</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
