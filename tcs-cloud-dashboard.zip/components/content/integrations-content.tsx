"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Plus } from "lucide-react"

export default function IntegrationsContent() {
  const [isModalOpen, setIsModalOpen] = useState(false)

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Integrations</h2>

      <div className="flex justify-end mb-5">
        <Button onClick={() => setIsModalOpen(true)}>
          <Plus className="mr-2 h-4 w-4" /> Add Integration
        </Button>
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Integration</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <Button className="w-full bg-blue-500 hover:bg-blue-600">Add API Integration</Button>
            <Button className="w-full bg-emerald-500 hover:bg-emerald-600">Add Webhook</Button>
            <Button className="w-full bg-amber-500 hover:bg-amber-600">Add Third-Party App</Button>
          </div>
          <Button variant="destructive" onClick={() => setIsModalOpen(false)} className="w-full">
            Cancel
          </Button>
        </DialogContent>
      </Dialog>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">API Integrations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">48</div>
            <div className="text-sm text-gray-500">Active integrations with internal and external systems</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Webhooks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">21</div>
            <div className="text-sm text-gray-500">Configured for event-driven triggers</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Third-Party Services</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">32</div>
            <div className="text-sm text-gray-500">Connected SaaS & infrastructure providers</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <Card>
          <CardHeader>
            <CardTitle>Popular Third-Party Integrations</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li>
                <strong>Slack:</strong> Real-time alert and notification integration
              </li>
              <li>
                <strong>Jira:</strong> Issue tracking and automation workflows
              </li>
              <li>
                <strong>GitHub:</strong> Repository and CI/CD automation
              </li>
              <li>
                <strong>ServiceNow:</strong> ITSM and incident management linkage
              </li>
              <li>
                <strong>PagerDuty:</strong> On-call scheduling and response automation
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent API Events</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Endpoint</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>2025-04-09 12:15</TableCell>
                  <TableCell>GitHub</TableCell>
                  <TableCell>/repos/push</TableCell>
                  <TableCell className="text-[#16c784]">200 OK</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-09 11:40</TableCell>
                  <TableCell>Slack</TableCell>
                  <TableCell>/alerts/send</TableCell>
                  <TableCell className="text-[#16c784]">200 OK</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-09 10:55</TableCell>
                  <TableCell>Jira</TableCell>
                  <TableCell>/issues/create</TableCell>
                  <TableCell className="text-[#f59e0b]">202 Accepted</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-09 10:12</TableCell>
                  <TableCell>PagerDuty</TableCell>
                  <TableCell>/incidents/trigger</TableCell>
                  <TableCell className="text-[#ef4444]">403 Forbidden</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
