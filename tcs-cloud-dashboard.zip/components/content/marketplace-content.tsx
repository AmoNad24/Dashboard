"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Plus } from "lucide-react"

export default function MarketplaceContent() {
  const [isModalOpen, setIsModalOpen] = useState(false)

  const marketplaceItems = [
    {
      id: 1,
      name: "Patternfly",
      provider: "Red Hat",
      icon: "/icons/patternfly.svg",
      description: "PatternFly is a community project that promotes design commonality and improves user experience.",
    },
    {
      id: 2,
      name: "ActiveMQ",
      provider: "Red Hat",
      icon: "/icons/activemq.png",
      description: "Allows messages to be sent/received to a JMS Queue or Topic using Apache ActiveMQ.",
    },
    {
      id: 3,
      name: "Apache Spark",
      provider: "Red Hat",
      icon: "/icons/apachespark.png",
      description: "This page covers the Apache Spark component for the Apache Camel.",
    },
    {
      id: 4,
      name: "Avro",
      provider: "Red Hat",
      icon: "/icons/avro.webp",
      description:
        "Provides a dataformat for avro, allowing serialization and deserialization of messages using Apache Avro.",
    },
    {
      id: 5,
      name: "Azure Services",
      provider: "Red Hat",
      icon: "/icons/azure.png",
      description: "The Camel Components provide connectivity to Azure services from Camel.",
    },
    {
      id: 6,
      name: "GPU Enabled Compute",
      provider: "Nvidia",
      icon: "/icons/Nvidia_logo.svg.png",
      description: "GPU Enabled Compute for your GPU Intensive workloads.",
    },
    {
      id: 7,
      name: "Dropbox",
      provider: "Red Hat",
      icon: "/icons/dropbox.png",
      description: "Allows you to treat Dropbox remote folders as a producer/consumer of messages.",
    },
    {
      id: 8,
      name: "Windows Server 2022 CIS",
      provider: "Microsoft",
      icon: "/icons/windows.png",
      description: "CIS Hardened image with preconfigured security baselines for Windows Server 2022.",
    },
    {
      id: 9,
      name: "MongoDB Atlas",
      provider: "MongoDB",
      icon: "/icons/MongoDB_Logo.svg.png",
      description: "Fully managed cloud database for modern apps with automated scaling and backups.",
    },
    {
      id: 10,
      name: "ElasticSearch",
      provider: "Elastic",
      icon: "/icons/elastic.png",
      description: "Search, analyze, and visualize data in real time with Elastic Stack.",
    },
    {
      id: 11,
      name: "PostgreSQL",
      provider: "Bitnami",
      icon: "/icons/postgres.png",
      description: "Open-source relational database engine, easy to deploy and scale in the cloud.",
    },
    {
      id: 12,
      name: "Grafana",
      provider: "Grafana Labs",
      icon: "/icons/grafana.webp",
      description: "Open-source analytics and monitoring platform for observability dashboards.",
    },
  ]

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Marketplace</h2>

      <div className="flex justify-end mb-5">
        <Button onClick={() => setIsModalOpen(true)}>
          <Plus className="mr-2 h-4 w-4" /> Add New Resource
        </Button>
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Marketplace Resource</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <Button className="w-full bg-blue-500 hover:bg-blue-600">Upload ISO</Button>
            <Button className="w-full bg-emerald-500 hover:bg-emerald-600">Add Image</Button>
            <Button className="w-full bg-amber-500 hover:bg-amber-600">Create Template</Button>
          </div>
          <Button variant="destructive" onClick={() => setIsModalOpen(false)} className="w-full">
            Cancel
          </Button>
        </DialogContent>
      </Dialog>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
        {marketplaceItems.map((item) => (
          <Card key={item.id} className="flex flex-col">
            <CardHeader className="pb-2">
              <div className="flex justify-center mb-2">
                <img src={item.icon || "/placeholder.svg"} alt={item.name} className="h-10" />
              </div>
              <CardTitle className="text-center">{item.name}</CardTitle>
            </CardHeader>
            <CardContent className="flex-grow">
              <small className="block text-gray-500 mb-2">Provided by {item.provider}</small>
              <p className="text-sm">{item.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
