"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ArrowUp, Server, Database, HardDrive } from "lucide-react"
import { FaDocker } from "react-icons/fa"
import { Chart } from "@/components/ui/chart"

export default function OverviewContent() {
  // Use refs to store chart instances
  const anomalyChartRef = useRef<HTMLCanvasElement>(null)
  const recCategoryChartRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    // Initialize charts when component mounts
    const anomalyChartData = {
      labels: ["Mon", "Tues", "Wed", "Thu", "Fri", "Sat", "Sun"],
      datasets: [
        {
          label: "Anomalies",
          data: [0, 5, 0, 1, 3, 1, 0],
          backgroundColor: "#10b981",
        },
        {
          label: "Fired Alerts",
          data: [0, 4, 0, 0, 2, 1, 0],
          backgroundColor: "#6366f1",
        },
        {
          label: "Anomaly Curve",
          type: "line",
          data: [0, 2, 1, 0.5, 1.5, 0.5, 0],
          borderColor: "rgba(16, 185, 129, 0.5)",
          backgroundColor: "rgba(16, 185, 129, 0.1)",
          fill: true,
          tension: 0.4,
          pointRadius: 0,
          borderWidth: 2,
        },
        {
          label: "Alert Curve",
          type: "line",
          data: [0, 1.5, 0.7, 0.2, 1.2, 0.4, 0],
          borderColor: "rgba(99, 102, 241, 0.5)",
          backgroundColor: "rgba(99, 102, 241, 0.1)",
          fill: true,
          tension: 0.4,
          pointRadius: 0,
          borderWidth: 2,
        },
      ],
    }

    const recCategoryChartData = {
      labels: ["Service Availability", "Fault Tolerance", "Performance", "Security"],
      datasets: [
        {
          data: [25, 4, 4, 12],
          backgroundColor: ["#3b82f6", "#93c5fd", "#2563eb", "#1e40af"],
        },
      ],
    }

    return () => {
      // Cleanup will be handled by the Chart component
    }
  }, [])

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8 bg-transparent border-0">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Instances</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">11.02K</div>
            <div className="flex items-center">
              <span className="text-[#16c784] flex items-center">
                <ArrowUp className="h-4 w-4 mr-1" /> 243
              </span>
              <small className="ml-2">(24 hours)</small>
              <Server className="ml-auto text-[#3b82f6]" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Containers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.31K</div>
            <div className="flex items-center">
              <span className="text-[#16c784] flex items-center">
                <ArrowUp className="h-4 w-4 mr-1" /> 4
              </span>
              <small className="ml-2">(24 hours)</small>
              <FaDocker className="ml-auto text-[#3b82f6] text-xl" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Database</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1.93K</div>
            <div className="flex items-center">
              <span className="text-[#16c784] flex items-center">
                <ArrowUp className="h-4 w-4 mr-1" /> 5
              </span>
              <small className="ml-2">(24 hours)</small>
              <Database className="ml-auto text-[#3b82f6]" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Storage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">543.86 TB</div>
            <div className="flex items-center">
              <span className="text-[#16c784] flex items-center">
                <ArrowUp className="h-4 w-4 mr-1" /> 15TB
              </span>
              <small className="ml-2">(24 hours)</small>
              <HardDrive className="ml-auto text-[#3b82f6]" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-5 mb-5">
        <Card>
          <CardHeader>
            <CardTitle>Anomalies vs Fired Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px]">
              <Chart
                id="anomalyAlertChart"
                type="bar"
                data={{
                  labels: ["Mon", "Tues", "Wed", "Thu", "Fri", "Sat", "Sun"],
                  datasets: [
                    {
                      label: "Anomalies",
                      data: [0, 5, 0, 1, 3, 1, 0],
                      backgroundColor: "#10b981",
                    },
                    {
                      label: "Fired Alerts",
                      data: [0, 4, 0, 0, 2, 1, 0],
                      backgroundColor: "#6366f1",
                    },
                    {
                      label: "Anomaly Curve",
                      type: "line",
                      data: [0, 2, 1, 0.5, 1.5, 0.5, 0],
                      borderColor: "rgba(16, 185, 129, 0.5)",
                      backgroundColor: "rgba(16, 185, 129, 0.1)",
                      fill: true,
                      tension: 0.4,
                      pointRadius: 0,
                      borderWidth: 2,
                    },
                    {
                      label: "Alert Curve",
                      type: "line",
                      data: [0, 1.5, 0.7, 0.2, 1.2, 0.4, 0],
                      borderColor: "rgba(99, 102, 241, 0.5)",
                      backgroundColor: "rgba(99, 102, 241, 0.1)",
                      fill: true,
                      tension: 0.4,
                      pointRadius: 0,
                      borderWidth: 2,
                    },
                  ],
                }}
                options={{
                  plugins: {
                    legend: {
                      position: "top",
                    },
                  },
                  responsive: true,
                  scales: {
                    y: {
                      beginAtZero: true,
                    },
                  },
                }}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Description</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>2025-03-31 10:00</TableCell>
                  <TableCell>admin</TableCell>
                  <TableCell>Deployed Kubernetes cluster</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-03-31 09:30</TableCell>
                  <TableCell>admin</TableCell>
                  <TableCell>Terminated VM: dev-server</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-03-30 16:12</TableCell>
                  <TableCell>admin</TableCell>
                  <TableCell>Updated firewall rules</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-03-30 12:40</TableCell>
                  <TableCell>admin</TableCell>
                  <TableCell>Created snapshot for db-server</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-03-30 11:20</TableCell>
                  <TableCell>admin</TableCell>
                  <TableCell>Restarted container: nginx-proxy</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Status</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-center">
                <div className="h-2 w-2 rounded-full bg-[#16c784] mr-2"></div>
                Cluster
              </li>
              <li className="flex items-center">
                <div className="h-2 w-2 rounded-full bg-[#fbbf24] mr-2"></div>
                Control Panel
              </li>
              <li className="flex items-center">
                <div className="h-2 w-2 rounded-full bg-[#fbbf24] mr-2"></div>
                Operators
                <small className="ml-2 text-gray-500">1 degraded</small>
              </li>
              <li className="flex items-center">
                <div className="h-2 w-2 rounded-full bg-[#16c784] mr-2"></div>
                Image Vulnerabilities
                <small className="ml-2 text-gray-500">0 vulnerabilities</small>
              </li>
              <li className="flex items-center">
                <div className="h-2 w-2 rounded-full bg-[#16c784] mr-2"></div>
                Storage
                <small className="ml-2 text-[#f87171]">Degraded</small>
              </li>
            </ul>

            <h4 className="font-medium mt-6 mb-3">Notifications</h4>
            <div className="flex flex-wrap gap-2">
              <span className="bg-[#ef4444] text-white px-3 py-1 rounded-full text-xs">1</span>
              <span className="bg-[#f59e0b] text-white px-3 py-1 rounded-full text-xs">1</span>
              <span className="bg-[#22c55e] text-white px-3 py-1 rounded-full text-xs">3</span>
              <span className="bg-[#60a5fa] text-white px-3 py-1 rounded-full text-xs">3</span>
              <span className="bg-[#7dd3fc] text-white px-3 py-1 rounded-full text-xs">3</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-5">
        <Card>
          <CardHeader>
            <CardTitle>Recommendations by Severity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-around text-center">
              <div>
                <div className="text-xl">2</div>
                <div className="text-[#f87171]">Critical</div>
              </div>
              <div>
                <div className="text-xl">5</div>
                <div className="text-[#facc15]">Important</div>
              </div>
              <div>
                <div className="text-xl">7</div>
                <div className="text-[#60a5fa]">Moderate</div>
              </div>
              <div>
                <div className="text-xl">12</div>
                <div className="text-[#9ca3af]">Low</div>
              </div>
            </div>

            <h4 className="font-medium mt-5 mb-3">Recommendations by Category</h4>
            <div className="flex items-center gap-5">
              <div className="w-[100px] h-[100px]">
                <Chart
                  id="recCategoryChart"
                  type="pie"
                  data={{
                    labels: ["Service Availability", "Fault Tolerance", "Performance", "Security"],
                    datasets: [
                      {
                        data: [25, 4, 4, 12],
                        backgroundColor: ["#3b82f6", "#93c5fd", "#2563eb", "#1e40af"],
                      },
                    ],
                  }}
                  options={{
                    plugins: {
                      legend: {
                        display: false,
                      },
                    },
                  }}
                />
              </div>
              <ul className="list-none p-0 m-0">
                <li className="text-[#93c5fd]">
                  Fault Tolerance: <span className="text-black">4</span>
                </li>
                <li className="text-[#3b82f6]">
                  Service Availability: <span className="text-black">25</span>
                </li>
                <li className="text-[#2563eb]">
                  Performance: <span className="text-black">4</span>
                </li>
                <li className="text-[#1e40af]">
                  Security: <span className="text-black">12</span>
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Improve Recommended Pathways</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-lg border border-[#dee2e6]">
                <span className="border border-[#60a5fa] text-[#60a5fa] px-2.5 py-0.5 rounded-full text-xs">
                  Performance
                </span>
                <a href="#" className="text-[#3b82f6] block mt-1">
                  378 systems
                </a>
                <p className="my-2.5 text-sm">
                  Upgrade your kernel version to remediate ntpd time sync issues, kernel panics, network instabilities
                  and issues with system performance
                </p>
                <p className="my-2.5 text-sm">
                  <span className="inline-block mr-1">⚡</span> System reboot <strong>is not</strong> required
                </p>
              </div>

              <div className="bg-white p-4 rounded-lg border border-[#dee2e6]">
                <span className="border border-[#60a5fa] text-[#60a5fa] px-2.5 py-0.5 rounded-full text-xs">
                  Stability
                </span>
                <a href="#" className="text-[#3b82f6] block mt-1">
                  211 systems
                </a>
                <p className="my-2.5 text-sm">
                  Adjust your networking configuration to get ahead of network performance degradations and packet
                  losses
                </p>
                <p className="my-2.5 text-sm">
                  <span className="inline-block mr-1">⚡</span> System reboot <strong>is</strong> required
                </p>
              </div>

              <div className="bg-white p-4 rounded-lg border border-[#dee2e6]">
                <span className="border border-[#60a5fa] text-[#60a5fa] px-2.5 py-0.5 rounded-full text-xs">
                  Availability
                </span>
                <a href="#" className="text-[#3b82f6] block mt-1">
                  166 systems
                </a>
                <p className="my-2.5 text-sm">
                  Fine tune your Oracle DB configuration to improve database performance and avoid process failure
                </p>
                <p className="my-2.5 text-sm">
                  <span className="inline-block mr-1">⚡</span> System reboot <strong>is not</strong> required
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
