"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Plus } from "lucide-react"

export default function AutomationCenterContent() {
  const [isModalOpen, setIsModalOpen] = useState(false)

  return (
    <div>
      <div className="flex justify-end mb-5">
        <Button onClick={() => setIsModalOpen(true)}>
          <Plus className="mr-2 h-4 w-4" /> Create New Automation
        </Button>
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Select Automation Type</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <Button className="w-full bg-blue-500 hover:bg-blue-600">Scheduled Task</Button>
            <Button className="w-full bg-emerald-500 hover:bg-emerald-600">Ansible Playbook</Button>
            <Button className="w-full bg-amber-500 hover:bg-amber-600">Terraform Script</Button>
            <Button className="w-full bg-cyan-500 hover:bg-cyan-600">Workflows</Button>
          </div>
          <Button variant="destructive" onClick={() => setIsModalOpen(false)} className="w-full">
            Cancel
          </Button>
        </DialogContent>
      </Dialog>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
        <Card>
          <CardHeader>
            <CardTitle>Scheduled Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li>
                <strong>Daily Backup:</strong> Executes every night at 2:00 AM
              </li>
              <li>
                <strong>Weekly Report Generation:</strong> Runs every Monday at 6:00 AM
              </li>
              <li>
                <strong>Log Rotation:</strong> Runs every 6 hours
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ansible Playbooks</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li>
                <strong>Provision VMs:</strong> Automates VM setup and configuration
              </li>
              <li>
                <strong>Patch Deployment:</strong> Applies security updates to servers
              </li>
              <li>
                <strong>App Deployment:</strong> Deploys latest application builds
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <Card>
          <CardHeader>
            <CardTitle>Terraform Infrastructure</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li>
                <strong>VPC Setup:</strong> Define and launch isolated cloud networks
              </li>
              <li>
                <strong>Instance Scaling:</strong> Automate scaling of compute instances
              </li>
              <li>
                <strong>DNS Configuration:</strong> Manage DNS zones and records
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Automation Logs</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Time</TableHead>
                  <TableHead>Automation</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>2025-04-09 10:12</TableCell>
                  <TableCell>Provision VMs</TableCell>
                  <TableCell className="text-[#16c784]">Success</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-09 09:00</TableCell>
                  <TableCell>Daily Backup</TableCell>
                  <TableCell className="text-[#16c784]">Success</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-08 15:30</TableCell>
                  <TableCell>Patch Deployment</TableCell>
                  <TableCell className="text-[#f59e0b]">Warning</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-08 10:00</TableCell>
                  <TableCell>Log Rotation</TableCell>
                  <TableCell className="text-[#ef4444]">Failed</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
