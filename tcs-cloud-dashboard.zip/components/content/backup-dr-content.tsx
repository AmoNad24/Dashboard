"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Chart } from "@/components/ui/chart"

export default function BackupDrContent() {
  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Backup Jobs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">312</div>
            <div className="text-sm text-gray-500">Scheduled and on-demand</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Restore Points</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,254</div>
            <div className="text-sm text-gray-500">Available for recovery</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Replication Jobs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">78</div>
            <div className="text-sm text-gray-500">Cross-region and on-prem</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">DR Plans</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <div className="text-sm text-gray-500">Active disaster recovery strategies</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
        <Card>
          <CardHeader>
            <CardTitle>Recent Backup Jobs</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Time</TableHead>
                  <TableHead>Resource</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>2025-04-15 02:00</TableCell>
                  <TableCell>VM: web-server-1</TableCell>
                  <TableCell>Scheduled</TableCell>
                  <TableCell className="text-[#16c784]">Success</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-14 23:15</TableCell>
                  <TableCell>DB: customer-data</TableCell>
                  <TableCell>On-Demand</TableCell>
                  <TableCell className="text-[#f59e0b]">Warning</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-14 21:30</TableCell>
                  <TableCell>Storage: nas-vol-2</TableCell>
                  <TableCell>Scheduled</TableCell>
                  <TableCell className="text-[#ef4444]">Failed</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>2025-04-14 19:45</TableCell>
                  <TableCell>VM: api-node</TableCell>
                  <TableCell>Scheduled</TableCell>
                  <TableCell className="text-[#16c784]">Success</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>DR Plan Status</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li>
                <strong>Region Failover:</strong> Tested on Apr 10 – <span className="text-[#16c784]">Successful</span>
              </li>
              <li>
                <strong>Critical App Recovery:</strong> Next test Apr 20
              </li>
              <li>
                <strong>DB Sync Policy:</strong> Real-time replication enabled
              </li>
              <li>
                <strong>VM Tier Plan:</strong> RPO: 30min, RTO: 1hr
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <Card>
          <CardHeader>
            <CardTitle>Backup Success Rate (Last 7 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="backupSuccessChart"
                type="line"
                data={{
                  labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
                  datasets: [
                    {
                      label: "Success Rate (%)",
                      data: [95, 96, 93, 94, 97, 98, 96],
                      borderColor: "#10b981",
                      backgroundColor: "rgba(16,185,129,0.2)",
                      fill: true,
                      tension: 0.4,
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                  scales: {
                    y: {
                      beginAtZero: true,
                      max: 100,
                      ticks: {
                        callback: (value: any) => `${value}%`,
                      },
                    },
                  },
                }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Restore Activity Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="restoreTrendChart"
                type="bar"
                data={{
                  labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
                  datasets: [
                    {
                      label: "Restore Jobs",
                      data: [3, 4, 2, 5, 6, 7, 5],
                      backgroundColor: "#3b82f6",
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                  scales: {
                    y: {
                      beginAtZero: true,
                    },
                  },
                }}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
