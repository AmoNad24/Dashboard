"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowUp } from "lucide-react"
import { Chart } from "@/components/ui/chart"

export default function ComplianceCenterContent() {
  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Intrusion Sets</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1.02K</div>
            <div className="flex items-center">
              <span className="text-[#16c784] flex items-center">
                <ArrowUp className="h-4 w-4 mr-1" /> 2
              </span>
              <small className="ml-2">(24 hours)</small>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Malware</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.31K</div>
            <div className="flex items-center">
              <span className="text-[#16c784] flex items-center">
                <ArrowUp className="h-4 w-4 mr-1" /> 4
              </span>
              <small className="ml-2">(24 hours)</small>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Reports</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">11.45K</div>
            <div className="flex items-center">
              <span className="text-[#16c784] flex items-center">
                <ArrowUp className="h-4 w-4 mr-1" /> 7
              </span>
              <small className="ml-2">(24 hours)</small>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Indicators</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1.1M</div>
            <div className="flex items-center">
              <span className="text-[#16c784] flex items-center">
                <ArrowUp className="h-4 w-4 mr-1" /> 2621
              </span>
              <small className="ml-2">(24 hours)</small>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
        <Card>
          <CardHeader>
            <CardTitle>Most Active Threats (Last 3 Months)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="activeThreatsChart"
                type="bar"
                data={{
                  labels: [
                    "Vo1d",
                    "Squamish Libra",
                    "UAC-0063",
                    "Dragon RaaS",
                    "PlushDaemon",
                    "Lotus Blossom",
                    "Earth Alux",
                    "FishMonger",
                    "Hive0145",
                    "Chinese-Speaking Group",
                  ],
                  datasets: [
                    {
                      label: "Threats",
                      data: [100, 95, 89, 83, 77, 70, 65, 59, 52, 49],
                      backgroundColor: "#ef4444",
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Most Targeted Victims (Last 3 Months)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="targetedVictimsChart"
                type="bar"
                data={{
                  labels: [
                    "Asia",
                    "Europe",
                    "Americas",
                    "Eastern Europe",
                    "Northern America",
                    "Southeastern Asia",
                    "Africa",
                    "Government",
                    "Eastern Asia",
                    "USA",
                  ],
                  datasets: [
                    {
                      label: "Victims",
                      data: [1000, 950, 920, 850, 820, 780, 700, 690, 660, 620],
                      backgroundColor: "#10b981",
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                }}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-5">
        <Card>
          <CardHeader>
            <CardTitle>Most Active Malware (Last 3 Months)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="activeMalwareChart"
                type="radar"
                data={{
                  labels: [
                    "Brute Ratel",
                    "SectopRAT",
                    "Lumma Stealer",
                    "ta505",
                    "Astral Stealer",
                    "NetSupport RAT",
                    "Information Stealer",
                    "QDoor",
                    "d3f4ckloader",
                    "ransomhub",
                  ],
                  datasets: [
                    {
                      label: "Malware",
                      data: [35, 40, 28, 25, 33, 41, 26, 38, 42, 30],
                      backgroundColor: "rgba(59,130,246,0.4)",
                      borderColor: "#3b82f6",
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Most Active Vulnerabilities (Last 3 Months)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="activeVulnerabilitiesChart"
                type="bar"
                data={{
                  labels: [
                    "CVE-2025-0282",
                    "CVE-2025-0283",
                    "CVE-2024-50623",
                    "CVE-2025-26633",
                    "CVE-2025-22457",
                    "CVE-2024-8963",
                    "CVE-2024-9379",
                    "CVE-2024-9381",
                  ],
                  datasets: [
                    {
                      label: "Vulnerabilities",
                      data: [58, 58, 33, 31, 25, 23, 23, 23],
                      backgroundColor: "#f59e0b",
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Targeted Countries (Last 3 Months)</CardTitle>
          </CardHeader>
          <CardContent>
            <img
              src="/map.png"
              alt="World map showing targeted countries"
              className="w-full h-[150px] rounded-lg object-cover"
            />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <Card>
          <CardHeader>
            <CardTitle>Latest Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="latestReportsChart"
                type="line"
                data={{
                  labels: ["Apr 1", "Apr 2", "Apr 3", "Apr 4", "Apr 5", "Apr 6", "Apr 7", "Apr 8", "Apr 9"],
                  datasets: [
                    {
                      label: "Reports",
                      data: [1, 3, 2, 5, 3, 6, 4, 2, 1],
                      borderColor: "#f43f5e",
                      backgroundColor: "rgba(244,63,94,0.2)",
                      fill: true,
                      tension: 0.4,
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Most Active Labels (Last 3 Months)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="activeLabelsChart"
                type="bar"
                data={{
                  labels: ["elf", "mozi", "mirai", "redteam", "trojan", "backdoor"],
                  datasets: [
                    {
                      label: "Mentions",
                      data: [80, 70, 65, 60, 58, 52],
                      backgroundColor: "#8b5cf6",
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                }}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
