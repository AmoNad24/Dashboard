"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Chart } from "@/components/ui/chart"

export default function IamContent() {
  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,204</div>
            <div className="text-sm text-gray-500">Across all accounts</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Roles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">78</div>
            <div className="text-sm text-gray-500">Custom and managed roles</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Access Keys</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">432</div>
            <div className="text-sm text-gray-500">Active keys</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Federated Identities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">29</div>
            <div className="text-sm text-gray-500">Linked providers</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
        <Card>
          <CardHeader>
            <CardTitle>Recent Login Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>IP Address</TableHead>
                  <TableHead>Region</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>admin</TableCell>
                  <TableCell>192.168.1.45</TableCell>
                  <TableCell>India-Mumbai</TableCell>
                  <TableCell>2025-04-15 10:42</TableCell>
                  <TableCell className="text-[#16c784]">Success</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>audit_user</TableCell>
                  <TableCell>172.16.3.22</TableCell>
                  <TableCell>Singapore</TableCell>
                  <TableCell>2025-04-15 09:37</TableCell>
                  <TableCell className="text-[#ef4444]">Failed</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>john.doe</TableCell>
                  <TableCell>10.1.2.13</TableCell>
                  <TableCell>Japan</TableCell>
                  <TableCell>2025-04-14 22:15</TableCell>
                  <TableCell className="text-[#16c784]">Success</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>analyst</TableCell>
                  <TableCell>10.0.0.19</TableCell>
                  <TableCell>Australia</TableCell>
                  <TableCell>2025-04-14 18:29</TableCell>
                  <TableCell className="text-[#f59e0b]">MFA Required</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Role Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="roleDistributionChart"
                type="pie"
                data={{
                  labels: ["Admin", "Read-Only", "DevOps", "Security", "Custom"],
                  datasets: [
                    {
                      data: [15, 25, 18, 10, 30],
                      backgroundColor: ["#3b82f6", "#10b981", "#f59e0b", "#8b5cf6", "#ef4444"],
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { position: "bottom" },
                  },
                }}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <Card>
          <CardHeader>
            <CardTitle>API Key Usage (Top 5)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <Chart
                id="apiKeyUsageChart"
                type="bar"
                data={{
                  labels: ["Key-A1", "Key-B2", "Key-C3", "Key-D4", "Key-E5"],
                  datasets: [
                    {
                      label: "Requests",
                      data: [1023, 875, 654, 492, 321],
                      backgroundColor: "#60a5fa",
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                  scales: {
                    y: {
                      beginAtZero: true,
                      ticks: {
                        callback: (value: any) => `${value} reqs`,
                      },
                    },
                  },
                }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>SSO Providers</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li>
                <strong>Azure AD:</strong> Enabled
              </li>
              <li>
                <strong>Okta:</strong> Enabled
              </li>
              <li>
                <strong>Google Workspace:</strong> Disabled
              </li>
              <li>
                <strong>Ping Identity:</strong> Enabled
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
