"use client"

import { useContent } from "@/context/content-context"
import OverviewContent from "@/components/content/overview-content"
import ResourcesContent from "@/components/content/resources-content"
import AutomationCenterContent from "@/components/content/automation-center-content"
import AiMlHubContent from "@/components/content/aiml-hub-content"
import ObservabilityContent from "@/components/content/observability-content"
import MarketplaceContent from "@/components/content/marketplace-content"
import ComplianceCenterContent from "@/components/content/compliance-center-content"
import IamContent from "@/components/content/iam-content"
import BackupDrContent from "@/components/content/backup-dr-content"
import ConfigManagementContent from "@/components/content/config-management-content"
import MigrationToolkitContent from "@/components/content/migration-toolkit-content"
import SupportCenterContent from "@/components/content/support-center-content"
import NotificationsContent from "@/components/content/notifications-content"
import CostManagementContent from "@/components/content/cost-management-content"
import IntegrationsContent from "@/components/content/integrations-content"

export default function MainContent() {
  const { activeContent } = useContent()

  return (
    <main className="flex-grow overflow-y-auto p-2.5 pb-10 mt-[60px] mb-[30px]">
      <div className={activeContent === "overview-content" ? "block" : "hidden"}>
        <OverviewContent />
      </div>
      <div className={activeContent === "resources-content" ? "block" : "hidden"}>
        <ResourcesContent />
      </div>
      <div className={activeContent === "automation-center-content" ? "block" : "hidden"}>
        <AutomationCenterContent />
      </div>
      <div className={activeContent === "aiml-hub-content" ? "block" : "hidden"}>
        <AiMlHubContent />
      </div>
      <div className={activeContent === "observability-content" ? "block" : "hidden"}>
        <ObservabilityContent />
      </div>
      <div className={activeContent === "marketplace-content" ? "block" : "hidden"}>
        <MarketplaceContent />
      </div>
      <div className={activeContent === "compliance-center-content" ? "block" : "hidden"}>
        <ComplianceCenterContent />
      </div>
      <div className={activeContent === "iam-content" ? "block" : "hidden"}>
        <IamContent />
      </div>
      <div className={activeContent === "backup--dr-content" ? "block" : "hidden"}>
        <BackupDrContent />
      </div>
      <div className={activeContent === "config-management-content" ? "block" : "hidden"}>
        <ConfigManagementContent />
      </div>
      <div className={activeContent === "migration-toolkit-content" ? "block" : "hidden"}>
        <MigrationToolkitContent />
      </div>
      <div className={activeContent === "support-center-content" ? "block" : "hidden"}>
        <SupportCenterContent />
      </div>
      <div className={activeContent === "notifications-content" ? "block" : "hidden"}>
        <NotificationsContent />
      </div>
      <div className={activeContent === "cost-management-content" ? "block" : "hidden"}>
        <CostManagementContent />
      </div>
      <div className={activeContent === "integrations-content" ? "block" : "hidden"}>
        <IntegrationsContent />
      </div>
    </main>
  )
}
