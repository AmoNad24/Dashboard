"use client"

import type React from "react"

import { useState } from "react"
import { cn } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"

interface SidebarItemProps {
  item: {
    id: string
    icon: LucideIcon
    label: string
    subItems?: {
      id: string
      icon: LucideIcon
      label: string
    }[]
  }
  isCollapsed: boolean
}

export function SidebarItem({ item, isCollapsed }: SidebarItemProps) {
  const [isActive, setIsActive] = useState(false)
  const Icon = item.icon

  const toggleActive = (e: React.MouseEvent) => {
    if (item.subItems) {
      e.stopPropagation()
      setIsActive(!isActive)
    }
  }

  return (
    <li className="my-1 text-xs cursor-pointer border-b border-[#dee2e6]" onClick={toggleActive}>
      <Icon className="inline-block mr-1.5" size={14} />
      {!isCollapsed && item.label}
      {item.subItems && (
        <ul className={cn("pl-4 hidden", isActive && "block", isCollapsed && "!hidden group-hover:!block")}>
          {item.subItems.map((subItem) => {
            const SubIcon = subItem.icon
            return (
              <li key={subItem.id} className="my-1 text-xs cursor-pointer">
                <SubIcon className="inline-block mr-1.5" size={14} />
                {!isCollapsed && subItem.label}
              </li>
            )
          })}
        </ul>
      )}
    </li>
  )
}
