"use client"

import { useEffect, useState } from "react"
import { cn } from "@/lib/utils"
import { useSidebar } from "@/context/sidebar-context"
import { useContent } from "@/context/content-context"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { SidebarCategory } from "@/components/sidebar-category"
import { sidebarData } from "@/data/sidebar-data"

export default function Sidebar() {
  const { isSidebarCollapsed, toggleSidebar } = useSidebar()
  const { setActiveContent } = useContent()
  const [activeCategories, setActiveCategories] = useState<string[]>([])

  useEffect(() => {
    // Load sidebar state from localStorage
    const sidebarState = localStorage.getItem("sidebarCollapsed")
    if (sidebarState === "true") {
      toggleSidebar(true)
    }
  }, [toggleSidebar])

  const toggleCategory = (categoryId: string) => {
    setActiveCategories((prev) => {
      if (prev.includes(categoryId)) {
        return prev.filter((id) => id !== categoryId)
      } else {
        return [...prev, categoryId]
      }
    })
  }

  const handleCategoryClick = (categoryId: string) => {
    toggleCategory(categoryId)
    const contentId = `${categoryId
      .toLowerCase()
      .replace(/ /g, "-")
      .replace(/[^a-z-]/g, "")}-content`
    setActiveContent(contentId)
    localStorage.setItem("activeContent", contentId)
  }

  return (
    <div
      className={cn(
        "mt-[40px] bg-[#F5F7FA] text-[#3b3b3b] border-r border-[#dee2e6] overflow-y-auto p-2.5 flex-shrink-0 transition-all duration-300 relative",
        isSidebarCollapsed ? "w-[35px] group" : "w-[175px]",
      )}
    >
      {sidebarData.map((category) => (
        <SidebarCategory
          key={category.id}
          category={category}
          isActive={activeCategories.includes(category.id)}
          isCollapsed={isSidebarCollapsed}
          onClick={() => handleCategoryClick(category.id)}
        />
      ))}

      <div
        className="absolute bottom-5 left-5 cursor-pointer text-gray-400"
        onClick={() => toggleSidebar(!isSidebarCollapsed)}
      >
        {isSidebarCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
      </div>
    </div>
  )
}
