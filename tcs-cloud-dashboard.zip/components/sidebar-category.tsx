"use client"

import { cn } from "@/lib/utils"
import { SidebarItem } from "@/components/sidebar-item"
import type { LucideIcon } from "lucide-react"

interface SidebarCategoryProps {
  category: {
    id: string
    icon: LucideIcon
    label: string
    items?: {
      id: string
      icon: LucideIcon
      label: string
      subItems?: {
        id: string
        icon: LucideIcon
        label: string
      }[]
    }[]
  }
  isActive: boolean
  isCollapsed: boolean
  onClick: () => void
}

export function SidebarCategory({ category, isActive, isCollapsed, onClick }: SidebarCategoryProps) {
  const Icon = category.icon

  return (
    <>
      <h2
        className={cn(
          "text-sm my-4 text-[#3b3b3b] border-b border-[#dee2e6] pb-1 cursor-pointer",
          isCollapsed && "text-center group-hover:text-left",
        )}
        onClick={onClick}
      >
        <Icon className="inline-block mr-1.5 group-hover:mr-1.5" size={16} />
        <span className={cn(isCollapsed && "hidden group-hover:inline")}>{category.label}</span>
      </h2>
      {category.items && (
        <ul className={cn("list-none pl-3 hidden", isActive && "block", isCollapsed && "!hidden group-hover:!block")}>
          {category.items.map((item) => (
            <SidebarItem key={item.id} item={item} isCollapsed={isCollapsed} />
          ))}
        </ul>
      )}
    </>
  )
}
