"use client"

import { useEffect } from "react"
import Sidebar from "@/components/sidebar"
import Topbar from "@/components/topbar"
import MainContent from "@/components/main-content"
import { useSidebar } from "@/context/sidebar-context"
import { useContent } from "@/context/content-context"

export default function Dashboard() {
  const { setActiveContent } = useContent()
  const { isSidebarCollapsed } = useSidebar()

  useEffect(() => {
    // Load saved content from localStorage
    const savedContent = localStorage.getItem("activeContent")
    if (savedContent) {
      setActiveContent(savedContent)
    }
  }, [setActiveContent])

  return (
    <div className="flex h-screen overflow-hidden bg-[#f8f9fa] text-[#212529]">
      <Sidebar />
      <div className="flex flex-grow flex-col h-full overflow-hidden relative">
        <Topbar />
        <MainContent />
      </div>
    </div>
  )
}
