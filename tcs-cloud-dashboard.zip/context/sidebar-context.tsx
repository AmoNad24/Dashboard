"use client"

import type React from "react"

import { createContext, useContext, useState } from "react"

interface SidebarContextType {
  isSidebarCollapsed: boolean
  toggleSidebar: (value?: boolean) => void
}

const SidebarContext = createContext<SidebarContextType>({
  isSidebarCollapsed: false,
  toggleSidebar: () => {},
})

export function SidebarProvider({ children }: { children: React.ReactNode }) {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)

  const toggleSidebar = (value?: boolean) => {
    const newValue = value !== undefined ? value : !isSidebarCollapsed
    setIsSidebarCollapsed(newValue)
    localStorage.setItem("sidebarCollapsed", newValue.toString())
  }

  return <SidebarContext.Provider value={{ isSidebarCollapsed, toggleSidebar }}>{children}</SidebarContext.Provider>
}

export const useSidebar = () => useContext(SidebarContext)
