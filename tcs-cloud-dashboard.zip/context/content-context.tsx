"use client"

import type React from "react"

import { createContext, useContext, useState } from "react"

interface ContentContextType {
  activeContent: string
  setActiveContent: (contentId: string) => void
}

const ContentContext = createContext<ContentContextType>({
  activeContent: "overview-content",
  setActiveContent: () => {},
})

export function ContentProvider({ children }: { children: React.ReactNode }) {
  const [activeContent, setActiveContent] = useState("overview-content")

  return <ContentContext.Provider value={{ activeContent, setActiveContent }}>{children}</ContentContext.Provider>
}

export const useContent = () => useContext(ContentContext)
